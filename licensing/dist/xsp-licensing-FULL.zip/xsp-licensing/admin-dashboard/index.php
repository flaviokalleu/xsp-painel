<?php
/**
 * XSP Admin Dashboard — painel simples para gerenciar licenças.
 *
 * Consome a api-license via ADMIN_TOKEN. Login basic auth local.
 * Subir como container ou em qualquer host PHP atrás de HTTPS.
 *
 * Variáveis de ambiente:
 *   ADMIN_API_BASE       ex: https://license.seudominio.com
 *   ADMIN_API_TOKEN      mesmo ADMIN_TOKEN da api-license
 *   ADMIN_DASH_USER      usuário do dashboard (basic auth)
 *   ADMIN_DASH_PASS      senha (bcrypt OU texto puro — usa hash se começa com $2y$)
 */

declare(strict_types=1);
session_start();

function env(string $k, string $d = ''): string {
    $v = getenv($k); return ($v === false || $v === '') ? $d : $v;
}

$API   = env('ADMIN_API_BASE', 'http://localhost:8443');
$TOK   = env('ADMIN_API_TOKEN', '');
$USER  = env('ADMIN_DASH_USER', 'admin');
$PASS  = env('ADMIN_DASH_PASS', 'admin');

/* ---------- auth ---------- */
function check_pw(string $given, string $stored): bool {
    if (str_starts_with($stored, '$2y$') || str_starts_with($stored, '$argon')) {
        return password_verify($given, $stored);
    }
    return hash_equals($stored, $given);
}

if (($_POST['action'] ?? '') === 'login') {
    if (($_POST['user'] ?? '') === $USER && check_pw($_POST['pass'] ?? '', $PASS)) {
        $_SESSION['ok'] = true;
        header('Location: ?'); exit;
    }
    $loginErr = 'Credenciais inválidas';
}
if (($_GET['action'] ?? '') === 'logout') {
    session_destroy(); header('Location: ?'); exit;
}
$logged = !empty($_SESSION['ok']);

/* ---------- API client ---------- */
function api(string $method, string $path, array $body = null): array {
    global $API, $TOK;
    $ch = curl_init($API . $path);
    $hdrs = ['Authorization: Bearer ' . $TOK, 'Content-Type: application/json'];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $hdrs,
        CURLOPT_TIMEOUT        => 10,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $r = curl_exec($ch);
    $c = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $c, 'body' => json_decode((string)$r, true) ?: ['raw' => $r]];
}

/* ---------- actions ---------- */
$flash = null;
if ($logged && ($_POST['action'] ?? '') === 'create_key') {
    $r = api('POST', '/admin/keys', [
        'email'      => $_POST['email']   ?? '',
        'name'       => $_POST['name']    ?? '',
        'plan_code'  => $_POST['plan']    ?? 'pro',
        'period_days'=> (int)($_POST['days'] ?? 30),
    ]);
    $flash = $r['code'] === 201
        ? ['ok',   'KEY criada: ' . ($r['body']['key'] ?? '')]
        : ['err',  json_encode($r['body'])];
}
if ($logged && ($_POST['action'] ?? '') === 'revoke') {
    $r = api('PATCH', '/admin/keys/' . $_POST['id'],
        ['status' => 'revoked', 'reason' => $_POST['reason'] ?? 'admin']);
    $flash = $r['code'] < 300 ? ['ok', 'Revogada'] : ['err', json_encode($r['body'])];
}
if ($logged && ($_POST['action'] ?? '') === 'extend') {
    $r = api('PATCH', '/admin/keys/' . $_POST['id'],
        ['extend_days' => (int)($_POST['days'] ?? 30)]);
    $flash = $r['code'] < 300 ? ['ok', 'Estendida'] : ['err', json_encode($r['body'])];
}
if ($logged && ($_POST['action'] ?? '') === 'blacklist') {
    $r = api('POST', '/admin/blacklist', [
        'kind' => $_POST['kind'], 'value' => $_POST['value'],
        'reason' => $_POST['reason'] ?? '',
    ]);
    $flash = $r['code'] < 300 ? ['ok', 'Adicionado'] : ['err', json_encode($r['body'])];
}

$licenses = [];
if ($logged) {
    $r = api('GET', '/admin/keys?limit=100&offset=0');
    if ($r['code'] === 200) $licenses = $r['body']['items'] ?? [];
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>XSP Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root { --bg:#0b1020; --fg:#e6edf3; --mut:#7d8590; --accent:#3fb950; --danger:#f85149;
        --card:#161b22; --border:#30363d; }
* { box-sizing:border-box; }
body { background:var(--bg); color:var(--fg); font-family:system-ui,-apple-system,sans-serif;
       margin:0; padding:24px; max-width:1400px; margin:auto; }
h1,h2 { margin:0 0 16px; }
header { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; }
.btn { background:var(--accent); border:none; color:#0b1020; padding:8px 14px; border-radius:6px;
       cursor:pointer; font-weight:600; }
.btn.danger { background:var(--danger); color:#fff; }
.btn.ghost  { background:transparent; color:var(--fg); border:1px solid var(--border); }
.card { background:var(--card); border:1px solid var(--border); border-radius:8px;
        padding:18px; margin-bottom:16px; }
.row { display:flex; gap:10px; flex-wrap:wrap; }
.row > * { flex:1; min-width:140px; }
input, select { background:#0d1117; color:var(--fg); border:1px solid var(--border);
                padding:8px; border-radius:6px; width:100%; }
table { width:100%; border-collapse:collapse; font-size:14px; }
th, td { padding:8px 10px; border-bottom:1px solid var(--border); text-align:left; }
th { background:#0d1117; color:var(--mut); font-weight:600; font-size:12px;
     text-transform:uppercase; letter-spacing:.5px; }
code { background:#0d1117; padding:2px 6px; border-radius:4px; font-size:13px; }
.badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px;
         font-weight:600; text-transform:uppercase; }
.badge.active { background:#1f6f3f; color:#d3ffd3; }
.badge.expired{ background:#754200; color:#ffe1b2; }
.badge.revoked{ background:#6e1e1e; color:#ffd2d2; }
.badge.suspended{ background:#3a3a3a; color:#ccc; }
.flash.ok  { background:#1f6f3f; color:#d3ffd3; padding:10px; border-radius:6px; margin-bottom:16px; }
.flash.err { background:#6e1e1e; color:#ffd2d2; padding:10px; border-radius:6px; margin-bottom:16px; }
.muted { color:var(--mut); font-size:13px; }
form.inline { display:inline; }
</style>
</head>
<body>

<?php if (!$logged): ?>
<div class="card" style="max-width:380px;margin:80px auto;">
  <h1>XSP Admin</h1>
  <?php if (!empty($loginErr)): ?><div class="flash err"><?= htmlspecialchars($loginErr) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="action" value="login">
    <p><input type="text" name="user" placeholder="usuário" required></p>
    <p><input type="password" name="pass" placeholder="senha" required></p>
    <p><button class="btn" type="submit">Entrar</button></p>
  </form>
</div>
<?php else: ?>

<header>
  <h1>XSP Admin</h1>
  <a class="btn ghost" href="?action=logout">Sair</a>
</header>

<?php if ($flash): ?>
  <div class="flash <?= $flash[0] ?>"><?= htmlspecialchars((string)$flash[1]) ?></div>
<?php endif; ?>

<div class="card">
  <h2>Criar nova licença</h2>
  <form method="post">
    <input type="hidden" name="action" value="create_key">
    <div class="row">
      <input type="email" name="email" placeholder="cliente@exemplo.com" required>
      <input type="text"  name="name"  placeholder="Nome">
      <select name="plan">
        <option value="trial">Trial</option>
        <option value="basic">Básico</option>
        <option value="pro" selected>Profissional</option>
        <option value="enterprise">Enterprise</option>
      </select>
      <input type="number" name="days" value="30" min="1" max="365">
      <button class="btn" type="submit">Gerar KEY</button>
    </div>
  </form>
</div>

<div class="card">
  <h2>Licenças (<?= count($licenses) ?>)</h2>
  <table>
    <thead>
      <tr>
        <th>KEY</th><th>Plano</th><th>Status</th><th>Expira em</th>
        <th>Max inst.</th><th>Criada</th><th>Ações</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($licenses as $l):
        $expIn = max(0, (int)((strtotime((string)$l['expires_at']) - time()) / 86400));
        $key = (string)($l['key'] ?? '???'); ?>
      <tr>
        <td><code><?= htmlspecialchars($key) ?></code></td>
        <td><?= htmlspecialchars((string)($l['plan_code'] ?? '')) ?></td>
        <td><span class="badge <?= htmlspecialchars((string)$l['status']) ?>">
            <?= htmlspecialchars((string)$l['status']) ?></span></td>
        <td><?= htmlspecialchars(substr((string)$l['expires_at'], 0, 10)) ?>
            <div class="muted"><?= $expIn ?> dias</div></td>
        <td><?= (int)($l['max_instances'] ?? 1) ?></td>
        <td><?= htmlspecialchars(substr((string)$l['created_at'], 0, 10)) ?></td>
        <td>
          <form class="inline" method="post" onsubmit="return confirm('Revogar?');">
            <input type="hidden" name="action" value="revoke">
            <input type="hidden" name="id" value="<?= htmlspecialchars((string)$l['id']) ?>">
            <input type="hidden" name="reason" value="admin">
            <button class="btn danger" type="submit">Revogar</button>
          </form>
          <form class="inline" method="post">
            <input type="hidden" name="action" value="extend">
            <input type="hidden" name="id" value="<?= htmlspecialchars((string)$l['id']) ?>">
            <input type="hidden" name="days" value="30">
            <button class="btn ghost" type="submit">+30d</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h2>Blacklist</h2>
  <form method="post">
    <input type="hidden" name="action" value="blacklist">
    <div class="row">
      <select name="kind">
        <option value="hwid">HWID</option>
        <option value="ip">IP</option>
        <option value="cidr">CIDR</option>
        <option value="key">KEY</option>
        <option value="email">Email</option>
      </select>
      <input type="text" name="value" placeholder="valor (ex: 192.168.1.0/24)" required>
      <input type="text" name="reason" placeholder="motivo">
      <button class="btn danger" type="submit">Bloquear</button>
    </div>
  </form>
</div>

<p class="muted">XSP Admin · API: <?= htmlspecialchars($API) ?></p>

<?php endif; ?>
</body>
</html>
