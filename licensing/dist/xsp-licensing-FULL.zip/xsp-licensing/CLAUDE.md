# Notas para Claude (sessões futuras)

## Contexto

Este diretório (`licensing/`) é o **sistema de licenciamento anti-pirataria**
construído para o painel PHP em `../script/` (Painel Office Xtream Server Pro V10).

O painel original é PHP 8.x + Apache + MySQL/MariaDB, distribuído via cPanel
historicamente. Por decisão do dono (Flavio, netsharkssh@gmail.com), a partir
da v10 a distribuição passa a ser **VPS Ubuntu via Docker apenas**, para
permitir blindar o código com cifragem AES-256-GCM + extensão C custom.

## Decisões de design importantes

1. **Sem ionCube/SourceGuardian** — encoder grátis. Usamos AES-256-GCM nos
   `.php` + extensão C `xsp_loader` (não PHP) para descriptografar.
2. **A master key vem da API a cada boot**, cifrada com HWID — nunca fica no
   disco do cliente.
3. **Stack do cliente roda em Docker** — instalador Go automatiza tudo, cliente
   só tem `.php.enc` ilegíveis no disco.
4. **Postgres na API central**, MariaDB no cliente. São separados.
5. **Heartbeat a cada 5 min**, cache offline máx 24h.
6. **Ed25519 para tokens**, HMAC-SHA256 para assinar requests, Argon2id para
   hash de KEY.

## Quando trabalhar aqui

- Se o usuário pedir nova funcionalidade do licenciamento, modifique a camada
  correta:
  - **Lógica de licença / planos** → `api-license/internal/`
  - **Comportamento do instalador** → `installer-go/`
  - **Validação no painel** → `painel-image/php-stub/`
  - **Cifragem / decifragem** → `xsp-loader/` ou `painel-image/build/`
- Se o usuário pedir mudança no painel **em si** (PHP do IPTV), trabalhe em
  `../script/` — esse é o código que será cifrado pelo pipeline.

## Arquivos com segredos / nunca commitar em repositório público

- `api-license/.env`            (contém ADMIN_TOKEN, master keys, Ed25519 priv)
- `installer-go/dist/`          (binários assinados)
- `/opt/xsp/keys/`              (chaves Ed25519 do release signing)
- Qualquer `MASTER_KEY` por versão de release

## Aviso de segurança já reportado ao usuário

O arquivo `../script/api/controles/db.php` contém credenciais de banco em
texto puro (`u874781703_painelags` / senha). O usuário foi avisado para
rotacionar a senha do banco antes de redistribuir o painel.
